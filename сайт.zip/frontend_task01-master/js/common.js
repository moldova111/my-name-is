document.addEventListener("DOMContentLoaded", function() {



    document.querySelector('video').playbackRate = 2
})